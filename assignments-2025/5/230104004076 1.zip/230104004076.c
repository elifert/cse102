#include <stdio.h>
#include <time.h>

void reset_game(int*, int*, int*, int*, int*, int*);
void game_board();
int hit_ships(int, int);
void generate_ship (int, FILE*);
int is_valid(int, int, FILE*, int, int);
void init_ships ();
void update_battleship (int, int);
int is_sunk (int size, int line1, int line2);
int control_input(int x, int y);

int main() {
    srand(time(NULL));
    int total_shots = 0, game_won = 0;
    int x = -1, y = -1, return_val_x, return_val_y, size;
    int sunk4 = 0, sunk3_1 = 0, sunk3_2 = 0, sunk2 = 0;
    char option;

    /* resetting the game if the user didnt finished it. */
    reset_game(&game_won, &total_shots, &sunk2, &sunk3_1, &sunk3_2, &sunk4);
    printf ("📢 Welcome to Battleship Game!\n");
    game_board();
    while (1) {
        printf("Enter coordinates (X to quit): ");
        return_val_x = scanf("%d", &x);
        if (return_val_x != 1) { /* if scanf can't read the input, it means it is a char or very big number. */
            scanf(" %c", &option); /* since previous scanf couldn't read the input, it is still present in the buffer. */
            if (option == 'X') {
                printf("Exiting the game...\n\n");
                while (getchar() != '\n');
                break;
            }
            else {
                printf("Invalid input! Please enter a number or X.\n");
                while (getchar() != '\n');
                continue;
            }
        }
        else {
            return_val_y = scanf("%d", &y);
            if (return_val_y != 1) {
                printf("Invalid input! Please enter a number or X.\n");
                while (getchar() != '\n');
                continue;
            }
            else if ((x > 9 || x < 0) || (y > 9 || y < 0)) {
                printf("Invalid coordinates! Please enter values betweeen 0 and 9.\n");
            }
            else if (control_input(x, y) == 0) {
                printf("You already hit these coordinates!\n");
            }
            else {
                update_battleship(x, y);
                size = hit_ships(x, y);
                if (size) {
                    if (size == 4)
                        sunk4 = is_sunk(4, 1, 4);
                    else if (size == 3) {
                        if (sunk3_1 != 1) sunk3_1 = is_sunk(3, 5, 7);
                        if (sunk3_2 != 1) sunk3_2 = is_sunk(3, 8, 10);
                    }
                    else if (size == 2)
                        sunk2 = is_sunk(2, 11, 12);
                }
                total_shots++;
                if (sunk2 == 1 && sunk3_1 == 1 && sunk3_2 == 1 && sunk4 == 1) { 
                    printf("\n🎉 All ships are sunk! Total shots: %d\n", total_shots);
                    game_won = 1;
                 }
            }
            while (getchar() != '\n');
        }
        game_board ();

        if (game_won == 1) {
            printf("Press 'N' to play again or 'X' to exit: ");
            while (scanf("%c", &option) != 1 || (option != 'X' && option != 'N')) {
                printf("Invalid input! Please enter N or X.\n");
                printf("Press 'N' to play again or 'X' to exit: ");
                while (getchar() != '\n');
            }
            if (option == 'X') { 
                printf("Exiting...\n");
                break;
            }
            else if (option == 'N') { 
                reset_game(&game_won, &total_shots, &sunk2, &sunk3_1, &sunk3_2, &sunk4);
                printf ("📢 Welcome to Battleship Game!\n");
                game_board();
                continue; 
            }
        }
    }
    return 0;
}

void reset_game(int *game_won, int* total_shots, int* sunk2, int* sunk3_1, int* sunk3_2, int* sunk4) {
    FILE *ships, *battleship_log;
    ships = fopen("ships.txt", "w");
    fclose(ships);
    battleship_log = fopen("battleship_log.txt", "w");
    fclose(battleship_log);
    init_ships();
    *game_won = 0;
    *total_shots = 0;
    *sunk2 = 0;
    *sunk3_1 = 0;
    *sunk3_2 = 0;
    *sunk4 = 0;
}

int is_valid(int x, int y, FILE* ships, int size, int orientation) {
    int ship_x, ship_y, i, new_x, new_y;
    if (ships == NULL) {
        return 1;
    }
    rewind(ships);
    while(fscanf(ships, "%d %d %d", &ship_x, &ship_y, &size) == 3) {
        for (i = 0; i < size; i++) {
            new_x = (orientation == 0) * i + x;
            new_y = (orientation == 1) * i + y;
            if (ship_x == new_x && ship_y == new_y) {
                return 0;
            }
        }
    }
    if ((orientation == 0 && x + size >= 9) || (orientation == 1 && y + size >= 9)) {
        return 0;
    }
    return 1;
}

void generate_ship (int size, FILE* ships) {
    int x, y, orientation, i, valid = 0;
    orientation = rand() % 2;
    while (valid == 0) {
        x = rand() % 10;
        y = rand() % 10;
        valid = is_valid(x, y, ships, size, orientation);
    }

    for (i = 0; i < size; i++) {
        if (orientation == 1) { /* horizontal */
            fprintf(ships, "%d %d %d\n", x, y + i, size);
        }
        else if (orientation == 0) { /* vertical */
            fprintf(ships, "%d %d %d\n", x + i, y, size);
        }
    }
    return ;
}

void init_ships () {
    FILE* ships;
    ships = fopen("ships.txt", "w+");
    if (ships == NULL) {
        printf("Could not create the file.\n");
        return ;
    }
    generate_ship(4, ships);
    generate_ship(3, ships);
    generate_ship(3, ships);
    generate_ship(2, ships);
    fclose(ships);
    return ;
}

void game_board() {
    FILE* battleship_log;
    int x_axis, y_axis, x, y, return_val = 3, size_of_ship;
    char result[10];
    battleship_log = fopen("battleship_log.txt", "r");
    if (battleship_log == NULL) {
        battleship_log = fopen("battleship_log.txt", "w+");
        if (battleship_log == NULL) {
            printf("Could not open the file.\n");
            return ;
        }
    }
    printf("\n ");
    for (y_axis = 0; y_axis < 10; y_axis++) {
        printf ("%2d", y_axis);
    }
    printf("\n");
    
    for (x_axis = 0; x_axis < 10; x_axis++) {
        printf("%d", x_axis);
        for (y_axis = 0; y_axis < 10; y_axis++) {
            while (return_val == 3) {
                return_val = fscanf(battleship_log, "Shot: %d %d - %s\n", &x, &y, result);
                if ((x == x_axis) && (y == y_axis)) { /* looking for the current x,y if it exists in the file */
                    break;
                }
            }
            /* resetting the fscanf */
            rewind(battleship_log);
            return_val = 3;

            if (x == x_axis && y == y_axis) {
                size_of_ship = hit_ships(x, y);
                if (size_of_ship != 0) {
                    printf(" X");

                }
                else {
                    printf(" O");
                }
            }
            else {
                printf(" -");
            }
        }
        printf("\n");
    }
    fclose(battleship_log);
    return ;
}

int hit_ships(int x, int y) {
    FILE* ships;
    int ship_x, ship_y, size, return_val = 3;
    ships = fopen("ships.txt", "r");
    while (return_val == 3) {
        return_val = fscanf(ships, "%d %d %d", &ship_x, &ship_y, &size);
        if (ship_x == x && ship_y == y) {
            fclose(ships);
            return size;
        }
    }
    fclose(ships);
    return 0;
}

void update_battleship (int x, int y) {
    FILE *battleship;
    int four_cell = 0, three_cell = 0, two_cell = 0, size, game_win = 0;
    battleship = fopen("battleship_log.txt", "a");
    if (battleship == NULL) {
        printf("ERROR: Could not open the file 'battleship_log.txt'.\n");
        return ;
    }

    if (hit_ships(x, y)) {
        fprintf(battleship, "Shot: %d %d - HIT\n", x, y);
        printf("HIT! 🎯\n");
    }
    else {
        fprintf(battleship, "Shot: %d %d - MISS\n", x, y);
        printf("MISS! ❌\n");
    }
    fclose(battleship);
    return ;
}


int is_sunk (int size, int line1, int line2) {
    FILE *battleship_log, *ships;
    int current_line = 0, ship_x, ship_y, ship_size, x, y, ship = 0;
    char result[10];
    battleship_log = fopen("battleship_log.txt", "r");
    ships = fopen("ships.txt", "r");
    while (current_line < line1) {
        fscanf(ships, "%d %d %d",&ship_x, &ship_y, &ship_size);
        current_line++;
    }
    
    for (;current_line <= line2 ;current_line++) {
        while (fscanf(battleship_log, "Shot: %d %d - %s\n", &x, &y, result) == 3) {
            if (ship_x == x && ship_y == y) {
                (ship)++;
            }
        }
        rewind(battleship_log);
        fscanf(ships, "%d %d %d",&ship_x, &ship_y, &ship_size);
    }
    fclose(battleship_log);
    fclose(ships);
    if (ship == size) {
        printf("Congratulations! You sank a %d-cell ship! 🚢🔥\n", size);
        return 1;
    }
    return 0;
}

int control_input(int x, int y) {
    FILE *battleship_log;
    int hit_x, hit_y;
    char result[10];
    battleship_log = fopen("battleship_log.txt", "r");
    if (battleship_log == NULL) {
        return 1;
    }
    while (fscanf(battleship_log, "Shot: %d %d - %s\n", &hit_x, &hit_y, result) == 3) {
        if (hit_x == x && hit_y == y) {
            return 0;
        }
    }
    fclose(battleship_log);
    return 1;
}