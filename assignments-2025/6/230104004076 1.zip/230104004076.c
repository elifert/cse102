#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int is_won(int*, int*);
void print_code_to_file(int *code);
int get_vault_config ();
int* generate_code();
int check_dupl(int digit, int *code, int code_len);
int* get_guess();
int write_game_log(int *);
void update_game_and_log(int attempt, int *guess, int *code, int *score);
int find_misplaced (int guess, int *code, int code_len);
void assign_title(int score);
int get_code_len();
int get_min_digit();
int get_max_digit ();
int allow_dupl ();
int get_correct_points ();
int get_misplc_points ();
int get_penalty_points ();
int get_value_by_key (const char *target_key);

int main() {
    srand(time(NULL));
    char option;
    int *code, *guess, attempts = 1, max_attempts = -1, score = 0, i;
    FILE *vault_config;
    guess = NULL;
    code = NULL;
    
    printf("Welcome to the Code Breaker Game!\n");
    while (1) {
        printf("Enter 'A' for admin, 'P' for player or 'E' to exit: ");
        while (scanf(" %c", &option) != 1 || (option != 'A' && option != 'P' && option != 'E')) {
            printf("Invalid option.\nPlease enter 'A' or 'P': ");
            while (getchar() != '\n');
        }
        if (option == 'A') {
            get_vault_config();
            printf("Saved to 'vault_config.txt'!\n\n");
        }
    
        else if (option == 'P') {
            vault_config = fopen("vault_config.txt", "r");
            if (!vault_config) {
                printf("ERROR: 'vault_config.txt' is not found.\n");
                continue;
            }
            code = generate_code();
            print_code_to_file(code);
            write_game_log(code);
            max_attempts = get_max_attempts();
            while (1) {
                printf("Attempt %d: ", attempts);
                if (attempts == 1) {
                    while (getchar() != '\n');
                }
                while ((guess = get_guess()) == NULL) {
                    printf("Invalid code guess.\n");
                    printf("Attempt %d: ", attempts);
                }
                update_game_and_log(attempts, guess, code, &score);
                if (is_won(code, guess)) {
                    printf("You guessed correctly!\n");
                    assign_title(score);
                    printf("To play again:\n");
                    attempts = 1;
                    score = 0;
                    break;
                }
                if (attempts == max_attempts) {
                    printf("You reached the max attempts.\n");
                    assign_title(score);
                    printf("To play again:\n");
                    attempts = 1;
                    score = 0;
                    break;
                }
                attempts++;
            }
        }

        else if (option == 'E') {
            printf("Exiting...\n");
            break;
        }
    }
    if (guess != NULL) free(guess);
    if (code != NULL) free(code);
    return 0;
}

void print_code_to_file(int *code) {
    int i, code_len;
    FILE *vault_code;
    vault_code = fopen("vault_code.txt", "w");
    code_len = get_code_len();
    for (i = 0; i < code_len; i++)
        fprintf(vault_code, "%d", code[i]);
    fclose(vault_code);
    return ;
}

int get_vault_config () {
    int code_len, min_digit, max_digit, max_attempts, duplicates, correct_points, misplc_points, penalty_points;
    FILE *vault_config;
    vault_config = fopen("vault_config.txt", "w");
    if (vault_config == NULL) {
        printf("ERROR: Cannot open the file 'vault_config.txt'\n");
        return 0;
    }

    printf("Enter code length: ");
    scanf("%d", &code_len);
    printf("Enter min and max digit: ");
    scanf("%d %d", &min_digit, &max_digit);
    printf("Enter max attempts: ");
    scanf("%d", &max_attempts);
    printf("Enter allow duplicates (1 for allowed, 0 for not allowed): ");
    scanf("%d", &duplicates);
    printf("Enter points for correct answer: ");
    scanf("%d", &correct_points);
    printf("Enter points for misplaced answers: ");
    scanf("%d", &misplc_points);
    printf("Enter points for penalty: ");
    scanf("%d", &penalty_points);

    fprintf(vault_config, "CODE_LENGTH=%d\nDIGIT_MIN=%d\nDIGIT_MAX=%d\nMAX_ATTEMPTS=%d\n", code_len, min_digit, max_digit, max_attempts);
    fprintf(vault_config, "ALLOW_DUPLICATES=%d\nPOINTS_CORRECT=%d\nPOINTS_MISPLACED=%d\nPENALTY_WRONG=%d\n", duplicates, correct_points, misplc_points, penalty_points);
    fclose(vault_config);
    return 1;
}

int* generate_code() {
    int code_len, min_digit, max_digit, duplicates, i;
    int *code, digit;
    code_len = get_code_len();
    min_digit = get_min_digit();
    max_digit = get_max_digit();
    duplicates = allow_dupl();
    code = malloc(sizeof(int) * code_len);
    for (i = 0; i < code_len; i++) {
        digit = rand() % (max_digit - min_digit + 1) + min_digit;
        if (duplicates == 0) {
            while (check_dupl(digit, code, i) && i != 0) {
                digit = rand() % (max_digit - min_digit + 1) + min_digit;
            }
        }
        code[i] = digit;
    }

    return code;
}

int check_dupl(int digit, int *code, int code_len) {
    int i;
    for (i = 0; i < code_len; i++) {
        if (digit == code[i]) return 1;
    }
    return 0;
}

int* get_guess() {
    int code_len, i, int_code, digit_num = 0, check_code;
    int *code;
    char *buff;
    code_len = get_code_len();
    code = malloc(sizeof(int) * code_len);
    if (code == NULL) {
        printf("Could not allocate memory for 'code'.\n");
        return NULL;
    }
    buff = malloc(sizeof(char) * 50);
    if (buff == NULL) {
        printf("Could not allocate memort for 'buff'\n");
        return NULL;
    }

    fgets(buff, 50, stdin);
    buff[strcspn(buff, "\n")] = '\0';

    if (strlen(buff) != code_len) {
        printf("Input must be exactly %d digits long.\n", code_len);
        free(code);
        return NULL;
    }

    for (i = 0; i < code_len; i++) {
        if(!(buff[i] >= '0' && buff[i] <= '9')) {
            free(code);
            return NULL;
        }
        code[i] = buff[i] - '0';
    }

    return code;
}

int write_game_log(int *code) {
    int code_len, min_digit, max_digit, duplicates, max_attempts, i;
    char date[100];
    FILE *game_log;
    time_t now = time(NULL);
    struct tm *timeinfo = localtime(&now);
    game_log = fopen("game_log.txt", "w");
    if (game_log == NULL) {
        printf("Could not open the file 'game_log.txt' on 'w' mode\n");
        return 0;
    }

    code_len = get_code_len();
    min_digit = get_min_digit();
    max_digit = get_max_digit();
    duplicates = allow_dupl();
    max_attempts = get_max_attempts(); 

    strftime(date, sizeof(date), "%Y-%m-%d %H:%M:%S", timeinfo);
    fprintf(game_log, "--- Vault Codebreaker Game Log ---\n");
    printf("--- Vault Codebreaker Game Log ---\n");
    fprintf(game_log, "Game Date: %s\n", date);
    printf("Game Date: %s\n", date);

    fprintf(game_log, "Secret code: ");
    for (i = 0; i < code_len; i++)
        fprintf(game_log, "%d", code[i]);
    fprintf(game_log, "\n");
    
    fprintf(game_log, "Code Length: %d\n", code_len);
    printf("Code Length: %d\n", code_len);
    fprintf(game_log, "Digit Range: %d-%d\n", min_digit, max_digit);
    printf("Digit Range: %d-%d\n", min_digit, max_digit);
    fprintf(game_log, "Duplicates Allowed: %d\n", duplicates);
    printf("Duplicates Allowed: %d\n", duplicates);
    fprintf(game_log, "Max Attempts: %d\n\n", max_attempts);
    printf("Max Attempts: %d\n\n", max_attempts);
    fclose(game_log);
    return 1;
}

void update_game_and_log(int attempt, int *guess, int *code, int *score) {
    int i, code_len, correct_points, misplc_points, penalty_points;
    char *feedback;
    FILE *game_log;

    game_log = fopen("game_log.txt", "a");
    code_len = get_code_len();
    correct_points = get_correct_points();
    misplc_points = get_misplc_points();
    penalty_points = get_penalty_points();
    feedback = malloc(sizeof(char) * code_len);

    fprintf(game_log, "Attempt %d: ", attempt);
    for (i = 0; i < code_len; i++)
        fprintf(game_log, "%d", guess[i]);
    fprintf(game_log, " ==> Feedback: ");
    printf ("==> Feedback: ");

    for (i = 0; i < code_len; i++) {
        if (guess[i] == code[i]) {
            fprintf(game_log, "C ");
            printf("C ");
            *score += correct_points;
        }
        else if (guess[i] != code[i]) {
            if (find_misplaced(guess[i], code, code_len) == 1) {
                fprintf(game_log, "M ");
                printf("M ");
                *score += misplc_points;
            }
            else {
                fprintf(game_log, "W ");
                printf("W ");
                *score -= penalty_points;
            }
        }
    }
    fprintf(game_log, "| Score: %d\n", *score);
    printf("| Score: %d\n", *score);
    fclose(game_log);
    free(feedback);
}

int find_misplaced (int guess, int *code, int code_len) {
    int i;
    for (i = 0; i < code_len; i++) {
        if (guess == code[i]) {
            return 1;
        }
    }
    return 0;
}

int is_won(int *code, int *guess) {
    int code_len, i;
    code_len = get_code_len();
    for (i = 0; i < code_len; i++) {
        if(code[i] != guess[i]) return 0;
    }
    return 1;
}

void assign_title(int score) {
    FILE *game_log;
    game_log = fopen("game_log.txt", "a");
    printf("Final Score: %d\nRank: ", score);
    fprintf(game_log, "Final Score: %d\nRank: ", score);
    if (score >= 90) {
        printf("Code Master 🧠\n");
        fprintf(game_log, "Code Master 🧠\n");
    }
    else if (score >= 70) {
        printf("Cipher Hunter 🔍\n");
        fprintf(game_log, "Cipher Hunter 🔍\n");
    }
    else if (score >= 50) {
        printf("Number Sleuth 🕵️‍♂️\n");
        fprintf(game_log, "Number Sleuth 🕵️‍♂️\n");
    }
    else if (score >= 30) {
        printf("Safe Kicker 💨\n");
        fprintf(game_log, "Safe Kicker 💨\n");
    }
    else if (score >= 10) {
        printf("Lucky Breaker 🍀\n");
        fprintf(game_log, "Lucky Breaker 🍀\n");
    }
    else {
        printf("Code Potato 🥔\n");
        fprintf(game_log, "Code Potato 🥔\n");
    }
    printf("\n");
    fclose(game_log);
}

int get_code_len() {
    return get_value_by_key("CODE_LENGTH");
}

int get_min_digit() {
    return get_value_by_key("DIGIT_MIN");
}

int get_max_digit () {
    return get_value_by_key("DIGIT_MAX");
}

int get_max_attempts () {
    return get_value_by_key("MAX_ATTEMPTS");
}

int allow_dupl () {
    return get_value_by_key("ALLOW_DUPLICATES");
}

int get_correct_points () {
    return get_value_by_key("POINTS_CORRECT");
}

int get_misplc_points () {
    return get_value_by_key("POINTS_MISPLACED");
}

int get_penalty_points () {
    return get_value_by_key("PENALTY_WRONG");
}

int get_value_by_key (const char *target_key) {
    int value;
    char key[30];
    FILE *vault_config;
    vault_config = fopen("vault_config.txt", "r");
    if (vault_config == NULL) {
        printf("Error opening config file");
        return 0;
    }
    while (fscanf(vault_config, "%29[^=]=%d\n", key, &value) == 2) {
        if (strcmp(key, target_key) == 0) {
            fclose(vault_config);
            return value;
        }
    }
    fclose(vault_config);
    return -1;
}