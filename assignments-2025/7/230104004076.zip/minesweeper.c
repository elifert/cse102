#include <stdio.h>
#define MAX_MOVES 100

int move_rows[MAX_MOVES];
int move_cols[MAX_MOVES];
int move_top = 0;
int mines[10][10];
int reveal[10][10];

void initialize_game(int*);
void generate_map (int);
int find_mines(int row, int col, int size);
int isEmpty();
void pop();
void push(int row, int col);
int find_mines(int row, int col, int size);
void print_map (int size);
void save_moves (int, int);
void update_reveal(int row, int col, int size);
int check_input (int row, int col);
void undo_rev(int row, int col, int size);

int main() {
    srand(time(NULL));
    int row, col, size, move_return, is_won = 0, non_mines, revealed_count;
    int i, j;
    char buff[20];

    initialize_game(&size);
    non_mines = find_non_mines(size);
    while (1) {
        print_map(size);
        revealed_count = count_revealed();
        if (find_mines(row, col, size) == -1) {
            printf("BOOM! You hit a mine. Game over.\n");
            break;
        }
        else if (non_mines == revealed_count) {
            printf("Congratulations! You won!\n");
            break;
        }

        printf("Enter move (row col) or 'undo': ");
        move_return = scanf("%d %d", &row, &col);
        if (move_return != 2) { /* if cannot read */
            scanf("%s", buff);
            if (strcmp(buff, "undo") == 0) {
                if (isEmpty()) printf("No move to undone.\n");
                else {
                    pop();
                    undo_rev(move_rows[move_top], move_cols[move_top], size);
                    printf("Last move undone.\n");
                }
            }

            else {
                printf("Enter 'undo' or valid coordinates.\n");
            }
            while (getchar() != '\n');
        }
        else if (check_input(row, col) == 0) {
            printf("You entered this move.\n");
            continue;
        }
        else if (row < 0 || row >= size || col < 0 || col >= size) {
            printf("Please enter valid row and column.\n");
        }
        else {
            push(row, col);
            update_reveal(move_rows[move_top - 1], move_cols[move_top - 1], size);            
        }
    }
    save_moves(move_top, size);
    
    return 0;
}

void initialize_game(int *size) {
    int i, j;
    FILE *moves;

    /* overwrite leftover contents */
    moves = fopen("moves.txt", "w");
    fprintf(moves, "---Game Moves---\n");
    fclose(moves);

    move_top = 0;
    *size = rand() % 9 + 2;
    /* generate map of size 'size' */
    generate_map(*size);
    for (i = 0; i < *size; i++) {
        for (j = 0; j < *size; j++) {
            mines[i][j] = find_mines(i, j, *size);
            reveal[i][j] = 0;
        }
    }
}

void generate_map (int size) {
    int mine, i, j;
    FILE *map;
    map = fopen("map.txt", "w");
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            mine = rand() % 2;
            if (mine == 1) {
                fprintf(map, "* ");
            }
            else {
                fprintf(map, ". ");
            }
        }
        fprintf(map, "\n");
    }
    fclose(map);
}

void save_moves (int total_moves, int size) {
    int i;
    FILE *moves;
    moves = fopen("moves.txt", "a");
    if (!moves) {
        printf("Error: could not create or append to the file 'moves.txt'\n");
        return ;
    }
    for (i = 1; i <= total_moves; i++) {
        fprintf(moves, "Move %d: (Row %d, Col %d)\n", i, move_rows[i - 1], move_cols[i - 1]);
    }

    fprintf(moves, "Total Moves: %d\n", total_moves);
    fclose(moves);
}

int find_mines(int row, int col, int size) {
    int mine, i, j, mines = 0;
    char scanned;
    FILE *map;
    map = fopen("map.txt", "r");
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            fscanf(map, "%c ", &scanned);
            if (row == i && col == j && scanned == '*') {
                return -1;
            }
            if ((row - 1 <= i && i <= row + 1) && (col - 1 <= j && j <= col + 1)) {
                if (scanned == '*') {
                    mines++;
                }
            }
        }
    }
    fclose(map);
    return mines;
}

int find_non_mines(int size) {
    int i, j, total = 0;
    char scanned;
    FILE *map;
    map = fopen("map.txt", "r");
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            fscanf(map, "%c ", &scanned);
            if (scanned == '.') {
                total++;
            }
        }
    }
    fclose(map);
    return total;
}

void print_map(int size) {
    int rows, cols, index = 0;
    int zero_rows, zero_cols;
    printf("\n ");
    for (cols = 0; cols < size; cols++) {
        printf ("%2d", cols);
    }
    printf("\n");
    
    for (rows = 0; rows < size; rows++) {
        printf("%d", rows);
        for (cols = 0; cols < size; cols++) {
            if (reveal[rows][cols] == 1) {
                if (mines[rows][cols] == -1) {
                    printf(" X");
                }
                else {
                    printf(" %d", mines[rows][cols]);
                }
            }
            else {
                printf(" #");
            }
        }
        printf("\n");
    }
}

void update_reveal(int row, int col, int size) {
    int i, j;

    if (reveal[row][col] == 1) return;
    if (row < 0 || row >= size || col < 0 || col >= size) return;
    reveal[row][col] = 1;

    if (find_mines(row, col, size) == 0) {
        for (i = row - 1; i <= row + 1; i++) {
            for (j = col - 1 ; j <= col + 1; j++) {
                update_reveal(i, j, size);
            }
        }
    }
}

void push(int row, int col) {
    if (move_top < MAX_MOVES) {
        move_rows[move_top] = row;
        move_cols[move_top] = col;
        move_top++;
    }
}

void pop() {
    if (move_top > 0) {
        move_top--;
    }

}

int isEmpty() {
    return move_top == 0;
}

int check_input (int row, int col) {
    int i;
    for (i = 0; i < move_top && move_top > 0; i++) {
        if (move_rows[i] == row && move_cols[i] == col) {
            return 0;
        }
    }
    return 1;
}

int count_revealed() {
    int i, j, count;
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            if (reveal[i][j] == 1) count++; 
        }
    }
    return count;
}

void undo_rev(int row, int col, int size) {
    int i, j;

    if (reveal[row][col] == 0) return;
    if (row < 0 || row >= size || col < 0 || col >= size) return;
    reveal[row][col] = 0;

    if (find_mines(row, col, size) == 0) {
        for (i = row - 1; i <= row + 1; i++) {
            for (j = col - 1 ; j <= col + 1; j++) {
                undo_rev(i, j, size);
            }
        }
    }
}